# fake distutils.core

def setup():
    print("setup called")
